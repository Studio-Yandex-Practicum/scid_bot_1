from .auth import router as user_router  # noqa
from .bot_menu import router as bot_menu_router  # noqa
from .contact_requests import router as contact_request_router  # noqa
from .managers import router as managers_router  # noqa
from .reviews import router as reviews_router  # noqa
