from .base_endpoints import router as frontend_base  # noqa
from .contact_requests import router as frontend_contact_requests_router # noqa
from .managers import router as frontend_manager_router # noqa
from .reviews import router as reviews_router # noqa
from .setting_bot_menu import router as frontend_bot_menu_router  # noqa
